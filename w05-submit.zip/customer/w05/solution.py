"""Customer rules for Qinghe's W05 membership workflow."""

from collections import defaultdict
from datetime import date
import re

from fde_product.w05.records import current_records, verify_basis

RULE_VERSION = "qinghe-w05-rules-20261008.1"
RECORD_RULES = (
    ("migration_records.csv", ("success",), "pos_source_id", "crm_source_id"),
    ("account_review_records.csv", ("current",), "left_source_id", "right_source_id"),
)
MISSING = {"", "-", "NULL", "无"}


def identity_evidence(accounts, materials):
    """Use effective business records as evidence for the course identity graph."""
    account_ids = {account["source_id"] for account in accounts}
    evidence, findings, explicit_singletons = [], [], set()
    outside_export = set()
    for filename, statuses, left_key, right_key in RECORD_RULES:
        active, ignored = current_records(
            materials[filename], materials["reference_date"], statuses
        )
        findings.extend({**item, "source_file": filename} for item in ignored)
        for number, row in active:
            left, right = row.get(left_key), row.get(right_key)
            relation = "same" if left_key == "pos_source_id" else row.get("conclusion")
            origin = {
                "source_file": filename,
                "source_row": number,
                "record_id": row["record_id"],
            }
            if row.get("scope") != "specified_accounts" or not verify_basis(row, materials):
                findings.append({**origin, "reason": "UNVERIFIED_BASIS_OR_SCOPE"})
                continue
            if left not in account_ids or (right and right not in account_ids):
                outside_export.update({left, right} & account_ids)
                findings.append({
                    **origin, "reason": "SOURCE_OUTSIDE_EXPORT", "sources": [left, right]
                })
                continue
            if relation == "verified_singleton" and not right:
                explicit_singletons.add(left)
                continue
            if relation not in {"same", "different", "unresolved"} or not right or left == right:
                findings.append({**origin, "reason": "UNSUPPORTED_IDENTITY_CONCLUSION"})
                continue
            evidence.append({
                "left": left,
                "right": right,
                "relation": relation,
                "evidence_id": row["record_id"],
                "source_file": filename,
                "source_row": number,
                "rule_version": RULE_VERSION,
            })
    coverage = covered_source_files(materials, "account_review")
    exceptions_name = "operational_verification.csv"
    review = materials.get("coverage", {}).get("account_review", {})
    exceptions = materials.get(exceptions_name)
    excluded = set(outside_export)
    if review.get("exceptions_file") == exceptions_name and exceptions is not None:
        rows, _ = current_records(exceptions, materials["reference_date"])
        excluded.update(row["source_id"] for _, row in rows
                        if row.get("kind") == "abnormal_identity")
    else:
        coverage = set()
    singletons = explicit_singletons | {
        account["source_id"] for account in accounts
        if account.get("source_file") in coverage and account["source_id"] not in excluded
    }
    return {
        "rule_version": RULE_VERSION,
        "evidence": evidence,
        "verified_singletons": sorted(singletons),
        "findings": findings,
    }


def covered_source_files(materials, topic):
    """Accept coverage only for the file revisions listed in the input manifest."""
    declaration = materials.get("coverage", {}).get(topic, {})
    current_hashes = materials.get("manifest", {}).get("sha256", {})
    reviewed_hashes = declaration.get("file_sha256", {})
    try:
        if date.fromisoformat(declaration.get("reviewed_at", "")) > date.fromisoformat(
            materials["reference_date"]
        ):
            return set()
    except ValueError:
        return set()
    return {
        name for name in declaration.get("scope_files", [])
        if name in current_hashes and reviewed_hashes.get(name) == current_hashes[name]
    }


def member_attributes(member_id, source_records):
    """Keep every known value and choose a representative only on agreement."""
    fields = {"names": [], "masked_mobiles": [], "tier": [], "registered_stores": []}
    sources = []
    for account in source_records:
        raw = account["raw"]
        name_key = "nm" if account["system"] == "CRM" else "name"
        store_field = "reg_shop" if account["system"] == "CRM" else None
        provenance = {key: account[key] for key in ("source_id", "source_file", "source_row")}
        for key, source_field, value in (
            ("names", name_key, raw.get(name_key)),
            ("masked_mobiles", "mobile", raw.get("mobile")),
            ("tier", "lv", raw.get("lv")),
            ("registered_stores", store_field, account.get("registered_store")),
        ):
            value = (value or "").strip()
            if value.upper() in MISSING:
                continue
            fields[key].append(value)
            sources.append({**provenance, "field": source_field, "value": value})
    values = {key: sorted(set(items)) for key, items in fields.items()}
    names, tiers = values["names"], values["tier"]
    return {
        "display_name": names[0] if len(names) == 1 else None,
        "names": names,
        "masked_mobiles": values["masked_mobiles"],
        "tier": tiers[0] if len(tiers) == 1 else None,
        "conflicts": {
            "name" if key == "names" else key: values[key]
            for key in ("names", "masked_mobiles", "tier")
            if len(values[key]) > 1
        },
        "source_ids": sorted(account["source_id"] for account in source_records),
        "registered_stores": values["registered_stores"],
        "sources": sources,
    }


CRM_MEMBERS = "crm_member_export.csv"
DO_NOT_CONTACT = "小林工作账_勿扰名单.csv"
CONTACT_CHECKS = "contact_scope_confirmation.csv"
OPERATIONS = "operational_verification.csv"
CHANNELS = ("telephone", "sms")
RESTRICTION_PREFIXES = {
    "请勿再联系": "all",
    "勿打电话": "telephone",
    "勿发短信": "sms",
}
RESTRICTION_PATTERN = re.compile(
    r"(?:^|[,，;；/\s])((?:请勿再联系|勿打电话|勿发短信)[^,，;；/]*)"
)


def restriction(source_id, scope, file, row, quote):
    return {
        "source_id": source_id,
        "scope": scope,
        "source_file": file,
        "source_row": row,
        "quote": quote,
        "rule_version": RULE_VERSION,
    }


def policy_index(materials):
    """Index business records once for the per-member preparation hook."""
    reference = materials["reference_date"]
    confirmations = defaultdict(set)
    active, _ = current_records(materials.get(CONTACT_CHECKS, []), reference)
    workbook = materials.get(DO_NOT_CONTACT, [])
    for _, row in active:
        if row.get("original_file") != DO_NOT_CONTACT or not verify_basis(row, materials):
            continue
        try:
            position = int(row["original_row"])
            original = workbook[position - 1]
        except (ValueError, IndexError, KeyError):
            continue
        scope = row.get("channel_scope")
        if (
            position < 1 or scope not in {"telephone", "sms", "all"}
            or row.get("scope") != "member_after_verified_identity"
            or row["source_id"] != "CRM:" + original["会员号"]
            or row.get("original_quote") != original["原因"]
        ):
            continue
        confirmations[(row["source_id"], position)].add(scope)

    restrictions, operations = defaultdict(list), defaultdict(list)
    for position, row in enumerate(workbook, 1):
        source_id = "CRM:" + row["会员号"]
        quote = row["原因"].strip()
        explicit = {scope for prefix, scope in RESTRICTION_PREFIXES.items()
                    if quote.startswith(prefix)}
        scopes = explicit | confirmations[(source_id, position)]
        for scope in sorted(scopes or {"unknown"}):
            restrictions[source_id].append(
                restriction(source_id, scope, DO_NOT_CONTACT, position, quote or "原因未提供")
            )

    active, _ = current_records(
        materials.get(OPERATIONS, []), reference, ("current", "pending", "suspected")
    )
    for position, row in active:
        kind, scope = row.get("kind"), row.get("scope")
        if kind not in {"employee", "abnormal_identity"}:
            continue
        confirmed = (
            row["status"] == "current" and row.get("conclusion") == "confirmed"
            and scope in {"member", "account"} and verify_basis(row, materials)
        )
        operations[row["source_id"]].append({
            "source_id": row["source_id"],
            "source_file": OPERATIONS,
            "source_row": position,
            "record_id": row["record_id"],
            "kind": kind,
            "scope": scope,
            "quote": row.get("summary") or row["record_id"],
            "verification": "confirmed" if confirmed else "unknown",
            "rule_version": RULE_VERSION,
        })
    coverage = covered_source_files(materials, "operational_verification")
    declaration = materials.get("coverage", {}).get("operational_verification", {})
    if not {"employee", "abnormal_identity"} <= set(declaration.get("checked_topics", [])):
        coverage = set()
    return restrictions, operations, coverage


def contact_constraints(member_id, source_records, materials, channel):
    """Apply account- and member-scoped exclusions and preserve channel uncertainty."""
    if "_w05_policy_index" not in materials:
        materials["_w05_policy_index"] = policy_index(materials)
    restrictions, operations, covered_files = materials["_w05_policy_index"]
    evidence, confirmed, pending = [], [], []
    source_ids = {item["source_id"] for item in source_records}
    for account in source_records:
        source_id = account["source_id"]
        evidence.extend(restrictions.get(source_id, ()))
        if account["system"] == "CRM":
            for match in RESTRICTION_PATTERN.finditer(account["raw"].get("tag") or ""):
                quote = match[1].strip()
                scope = next(scope for prefix, scope in RESTRICTION_PREFIXES.items()
                             if quote.startswith(prefix))
                evidence.append(restriction(source_id, scope, account["source_file"],
                                            account["source_row"], quote))
        for record in operations.get(source_id, ()):
            (confirmed if record["verification"] == "confirmed" else pending).append(record)
    complete = bool(source_records) and all(
        item["source_file"] in covered_files for item in source_records
    )
    if not complete:
        pending.append({"reason": "OPERATIONAL_COVERAGE_UNVERIFIED", "source_ids": sorted(source_ids)})
    scopes = {item["scope"] for item in evidence}
    channels = {
        name: "blocked" if name in scopes or "all" in scopes
        else "unknown" if "unknown" in scopes else "no_known_restriction"
        for name in CHANNELS
    }
    account_exclusions = {item["source_id"] for item in confirmed if item["scope"] == "account"}
    return {
        "member_id": member_id,
        "status": "unknown" if pending or "unknown" in scopes else "ok",
        "channels": channels,
        "restriction_evidence": evidence,
        "member_excluded": any(item["scope"] == "member" for item in confirmed),
        "account_exclusions": sorted(account_exclusions),
        "all_source_accounts_excluded": bool(source_ids) and source_ids <= account_exclusions,
        "confirmed_exclusions": confirmed,
        "pending_verifications": pending,
        "verification_coverage_complete": complete,
        "actual_contact_authorized": False,
    }
