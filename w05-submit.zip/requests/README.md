# 复跑请求说明

所有 JSON 路径以课程 W05 r7 工程根目录为基准。下列映射还原本次实际输入。正式代码使用提交目录下的 customer/w05 文件，依赖使用提交的 requirements-w05.lock.txt。

| 请求中的路径 | 新工程中的来源 |
| --- | --- |
| data/w05-v2 | 发放的 W05 v2 数据包，按数据核对证据检查版本和哈希 |
| artifacts/w04/cleaned | 本人 W04 修订版 run-04 的 c3 清洗结果及 manifest.json。按同版源数据和个人 W04 适配器重建 |
| work/library-step4 | evidence/replay-input-libraries/formal |
| work/library | evidence/replay-input-libraries/d-variant，仅用于 D 组 |
| work/d/customer/w05 | requests/d-variant，仅用于 D 组 |
| work/report.json | artifacts/w05/mvp_v1_report.json |

在新工程中按请求生成新准备目录及新 home，依次运行 prepare、bind、init。若路径已存在，在 prepare 和 bind 请求中一起换新编号。按 evidence 中保存的请求复核，另填导出请求，指向新准备批次和新绑定，再导出到新目录。原状态清单、绑定摘要和模型运行证据供对照。

D 组的 variant 仅用于对照。正式提交的源码、有效库、状态和报告对应 prepared-5 / home-4。

指标库的历史发布元数据保留在原样快照。requests 下的 JSON 均是实际运行请求，路径按新工程根目录解析。首轮预检记录及原因见 evidence/step-8/precheck-first-failed.json。
