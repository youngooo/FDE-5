"""Independent read of current input and accepted orders, before formal entry calls."""
from collections import defaultdict
from datetime import date
from pathlib import Path
import csv
import json
import unicodedata

ROOT = Path("data/w05-v2")
BATCH = Path("work/prepared-5")
OUT = Path(__file__).parent
REF = date(2026, 9, 1)


def csv_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


mapping = {row["source_id"]: row for row in json.loads(
    (BATCH / "state/mapping.json").read_text()
)}
crm = {f"CRM:{row['hy_id']}": row for row in csv_rows(ROOT / "crm_member_export.csv")}
stores = defaultdict(set)
for key, row in crm.items():
    member_id = mapping[key]["member_id"]
    store = unicodedata.normalize("NFKC", row["reg_shop"]).strip().upper()
    if member_id and store:
        stores[member_id].add(store)

net = defaultdict(int)
latest = {}
august_net = 0
august_buyers = set()
a_id = mapping["CRM:QH10047866"]["member_id"]
a_accounts = sorted(sid for sid, row in mapping.items() if row["member_id"] == a_id)
assert mapping["POS:POS58564"]["member_id"] == a_id
migration = csv_rows(ROOT / "migration_records.csv")[0]
assert migration["record_id"] == "MG-3b3252281c913f405f78"
assert migration["status"] == "success"
a_orders = []
for row in csv_rows(BATCH / "cleaned/orders.csv"):
    mid, day = row["member_id"], row["ordered_at"]
    value = int(row["paid_cents"]) - int(row["refund_cents"])
    if mid == a_id:
        a_orders.append(row["order_id"])
    if row["status"] != "paid":
        continue
    if "2026-08-01" <= day < REF.isoformat():
        august_net += value
        if value > 0:
            august_buyers.add(mid)
    if "2025-09-01" <= day < REF.isoformat():
        net[mid] += value
    if value > 0 and day < REF.isoformat():
        latest[mid] = max(day, latest.get(mid, ""))

b_expected = {}
for store in ("1203", "1004"):
    candidates = []
    for mid, spend in sorted(net.items()):
        last = latest.get(mid)
        if store not in stores[mid] or spend < 300_000 or not last:
            continue
        days = (REF - date.fromisoformat(last)).days
        if days >= 60:
            candidates.append({"member_id": mid, "net_sales_cents": spend,
                               "last_effective_purchase": last, "days": days})
    b_expected[store] = candidates

workbook = csv_rows(ROOT / "小林工作账_勿扰名单.csv")
confirmation = csv_rows(ROOT / "contact_scope_confirmation.csv")
c = {}
for tag, sid, pos, channel, state in (
    ("phone-blocked", "CRM:QH10016769", 1, "telephone", "blocked"),
    ("channel-unknown", "CRM:QH10012924", 2, "sms", "unknown"),
):
    found = confirmation[pos-1]
    assert found["source_id"] == sid
    assert workbook[pos-1]["会员号"] == sid.removeprefix("CRM:")
    if state == "blocked":
        assert "勿打电话" in crm[sid]["tag"]
        assert found["status"] == "current" and found["channel_scope"] == "telephone"
    else:
        assert found["status"] == "pending" and found["channel_scope"] == "unknown"
        assert workbook[pos-1]["原因"] == "其他"
    c[tag] = {"member_id": mapping[sid]["member_id"], "source_id": sid, "channel": channel,
              "expected": state, "workbook_row": pos, "crm_note": crm[sid]["tag"],
              "confirmation": {"status":found["status"],"scope":found["channel_scope"]},
              "actual_contact_authorized": False}
expected = {
    "batch": str(BATCH),
    "method": "原始注册门店、公开迁移和联系确认、稳定映射及逐笔已接收订单独立扫描。不调用工具、平台圈选或 Agent；B 的渠道处置另外由政策证据核对。",
    "A": {"net_sales_cents": august_net, "member_id": a_id, "source_ids": a_accounts,
          "order_ids": sorted(a_orders), "migration_record": migration["record_id"]},
    "B": b_expected, "C": c,
    "E_buyer_count": {"expected": len(august_buyers), "unit": "购买财务实体", "precise_person_total":"pending"},
}
(OUT / "expected-a-c.json").write_text(json.dumps(expected,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(expected,ensure_ascii=False))
