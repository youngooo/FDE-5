"""人工小样本。使用内存数据库，避免改变青禾原始订单。"""
from datetime import date, timedelta
import unittest

import duckdb

from customer.w05.solution import identity_evidence
from fde_product.w05.features import recent_purchase
from fde_product.w05.identity import resolve

REF = date(2026, 9, 1)


class PurchaseBoundary(unittest.TestCase):
    def setUp(self):
        self.db = duckdb.connect(":memory:")
        self.addCleanup(self.db.close)
        self.db.execute("create table raw_members(member_id varchar)")
        self.db.execute("insert into raw_members values ('sample')")
        self.db.execute("""create table raw_orders(
            member_id varchar, ordered_at date, status varchar,
            paid_cents integer, refund_cents integer)""")

    def add(self, days, status="paid", paid=1000, refunded=0):
        self.db.execute("insert into raw_orders values ('sample',?,?,?,?)",
                        [REF - timedelta(days=days), status, paid, refunded])

    def check_purchase(self):
        return recent_purchase(self.db, {"coverage":["2024-09-01","2026-09-01"]},
                               {"member_id":"sample","reference_date":REF.isoformat(),"dormant_days":60})

    def test_59_60_61(self):
        for days, expected in [(59, False), (60, True), (61, True)]:
            with self.subTest(days=days):
                self.db.execute("delete from raw_orders")
                self.add(days)
                result = self.check_purchase()
                self.assertEqual(result["dormant_days"], days)
                self.assertIs(result["is_dormant"], expected)

    def test_cancelled_and_refunded_never_replace_effective_purchase(self):
        self.add(59, "cancelled", 0)
        self.add(2, refunded=1000)
        unknown = self.check_purchase()
        self.assertEqual(unknown["status"], "unknown")
        self.assertIsNone(unknown["is_dormant"])
        self.add(61)
        result = self.check_purchase()
        self.assertEqual(result["dormant_days"], 61)
        self.assertIs(result["is_dormant"], True)


class IdentityBoundary(unittest.TestCase):
    def test_weak_clues_are_not_evidence(self):
        ids = ["CRM:sample-a", "POS:sample-b"]
        accounts = [{"source_id":sid,"source_file":"sample.csv",
                     "raw":{"name":"同名样本","mobile":"138****0000"}} for sid in ids]
        materials = {"reference_date":REF.isoformat(),"migration_records.csv":[],
                     "account_review_records.csv":[]}
        outcome = identity_evidence(accounts, materials)
        self.assertEqual(outcome["evidence"], [])
        results = resolve(ids,outcome["evidence"],mapping_version=outcome["rule_version"],
                          verified_singletons=outcome["verified_singletons"])
        self.assertTrue(all(row["status"]=="unresolved" and row["member_id"] is None
                            for row in results))

    def test_conflicting_valid_evidence_blocks_merge(self):
        left,right = "CRM:sample-a","POS:sample-b"
        evidence = [{"left":left,"right":right,"relation":relation,"evidence_id":f"row-{n}",
                     "source_file":"synthetic.csv","source_row":n,"rule_version":"test"}
                    for n,relation in enumerate(("same","different"),1)]
        result = resolve([left,right],evidence,mapping_version="test")
        self.assertTrue(all(row["status"]=="conflict" and row["member_id"] is None
                            for row in result))


if __name__ == "__main__":
    unittest.main(verbosity=2)
